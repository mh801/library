window.addEvent('load',function () {
	$$('a[href*=vimeo]').each(function(el){
		el.addEvent('click',function(ev){
			ev.stop();
			openOverlay();
			$('content_area').setProperty('html','<iframe src="'+el.getProperty('href')+'?title=0&amp;byline=0&amp;portrait=0&amp;badge=0&amp;color=000000&amp;autoplay=1" width="700" height="394" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>');
			//$('content_area').setProperty('html','<iframe src="http://player.vimeo.com/video/71316649?title=0&amp;byline=0&amp;portrait=0&amp;badge=0&amp;color=ffffff&amp;autoplay=1" width="700" height="394" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>');
		});
	});
	var rotatemoving = false;
	if($$('#home_rotator .rotate').length > 1){
		$$('#home_rotator .rotate').each(function(el,idx){
			el.setStyle('top',$('home_rotator').getStyle('height').toInt()*idx);
			el.setProperty('id','home_rotator_'+idx);
			var rotatorclass = '';
			if(idx == 0){
				rotatorclass = 'active'
			}
			var rotatorcontrol = new Element('a',{'href':'#','class':rotatorclass,'id':'rotate_control_'+idx}).inject('rotate_controls');
			rotatorcontrol.addEvent('click',function(ev){
				ev.stop();
				$clear(rotatortimer);
				if(!rotatemoving){
					rotatemoving = true;
					$$('#rotate_controls a').each(function(elem){
						elem.removeClass('active');
					});
					this.addClass('active');
					var rotatordistance = 0;
					$$('#home_rotator .rotate').each(function(el,idx){
						if(this.getProperty('id').substring(15) == el.getProperty('id').substring(13)){
							rotatordistance = el.getStyle('top').toInt();
						}
					},this);
					$$('#home_rotator .rotate').each(function(el,idx){
						el.tween('top',el.getStyle('top').toInt(),(el.getStyle('top').toInt()-rotatordistance));
					});
					(function(){
						rotatemoving = false;
					}).delay(500);
				}
			});
		});
		var rotatortimer = (function(){
			rotatemoving = true;
			if($('home_rotator').getLast('.rotate').getStyle('top').toInt() == 0){
				var rotatordistance = 417;
				$$('#home_rotator .rotate').each(function(el,idx){
					if(idx == 0){
						rotatordistance = Math.abs(el.getStyle('top').toInt());
						$$('#rotate_controls a').each(function(elem){
							elem.removeClass('active');
						});
						$('rotate_controls').getFirst('a').addClass('active');
					}
					el.tween('top',el.getStyle('top').toInt(),(el.getStyle('top').toInt()+rotatordistance));
				});
			}
			else{
				$$('#rotate_controls a').each(function(elem){
					elem.removeClass('active');
				});
				$$('#home_rotator .rotate').each(function(el,idx){
					rotatornewtop = el.getStyle('top').toInt()-$('home_rotator').getSize().y.toInt();
					el.tween('top',el.getStyle('top').toInt(),rotatornewtop);
					if(rotatornewtop == 0){
						$('rotate_control_'+el.getProperty('id').substring(13)).addClass('active');
					}
				});
			}
			(function(){
				rotatemoving = false;
			}).delay(500);
		}).periodical(5000);
	}
});


function openOverlay(){
	new Fx.Scroll(window).toTop();
	$('single_view_overlay').store('currpos',window.getScroll());
	$('single_view_overlay').setStyles({'width':'100%','height':document.body.getSize().y,'opacity':0,'display':'block'});
	$('single_view_overlay').fade('in');
	$(document.body).setStyle('overflow','hidden');
	window.addEvent('resize',resizeOverlay);
	$('single_view_overlay').addEvent('click',closeOverlay);
	$('close_page').getElement('a').addEvent('click',function(ev){
		closeOverlay(ev);
	});
}

function resizeOverlay(){
	$('single_view_overlay').setStyles({'width':'100%','height':document.body.getSize().y});
}

function closeOverlay(ev){
	if(ev){
		ev.stop();
	}
	$('single_view_overlay').fade('out');
	(function(){
		$('single_view_overlay').setStyle('display','none');
		$(document.body).setStyle('overflow','');
		new Fx.Scroll(window).start($('single_view_overlay').retrieve('currpos').x,$('single_view_overlay').retrieve('currpos').y);
	}).delay(500);
	$('content_area').empty();
	window.removeEvent('resize',resizeOverlay);
	$('single_view_overlay').removeEvent('click',closeOverlay);
	$('close_page').getElement('a').removeEvents();
}

