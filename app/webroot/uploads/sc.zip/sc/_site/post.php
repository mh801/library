<?php
/**
* Lead Import Script To add Lead Data to T3 Database
*/
class Lead{

    private $db_connection           = null;
    private $lead_data               = array();
    private $media_piece_id          = null;
    private $marketing_piece_id      = null;
    private $lead_health_plan_id     = null;
    public $post_data_valid          = false;
    private $allowed_post_parameters = array(
        'first_name',
        'last_name',
        'phone',
        'email',
    );

    private $hStore_items = array(
        'email',
        'media_piece_id',
        'marketing_piece_id'
    );

    public function __construct(){
        $this->lead_data       = array();
        $this->post_data_valid = false;
    }

    /**
    * Create a connection to the T3 Database
    */
    private function initialize_database_connection(){

        $url         = parse_url($_SERVER['HTTP_HOST']);
        $url['host'] = explode('.', $url['path']);

        // Check to see if the subdomain name has the word 'test' in it so we dont write to the wrong DB
        if (strpos($url['host'][0],'test') !== false) {
            $enviroment = 'test';
        }else{
            $enviroment = 'production';
        }
        // $enviroment = 'production';

        // DB1 Database Settings
        if($enviroment == 'production'){
            $host     = 'db01.truhearing.com';
            $dbname   = 'securetruhearingcom';
            $user     = 'securemicrouser';
            $password = 'ID1dY0uC@llY0urM0therTod@y';
        }

        // DB2 Database Settings
        if($enviroment == 'test'){
            $host     = 'db2.truhearing.com';
            $dbname   = 'staging';
            $user     = 'securemicrouser';
            $password = 'ID1dY0uC@llY0urM0therTod@y';
        }

        $this->db_connection = pg_connect("host=".$host." dbname=".$dbname." user=".$user." password=".$password."");
        if(!$this->db_connection){
            print_r('Could not access database');
            exit;
        }
    }

    /**
    * Sets the MediaPieceId that will eventually tie this Lead to the correct Marketing Path
    */
    public function set_media_piece($media_piece_id){
        $this->media_piece_id = $media_piece_id;
    }

    /**
    * Sets the MarketingPieceId that will eventually tie this Lead to the correct Marketing Path
    */
    public function set_marketing_piece($marketing_piece_id){
        $this->marketing_piece_id = $marketing_piece_id;
    }

    /**
    * Sets the LeadHealthPlanId that will eventually tie this Lead to the correct Marketing Path
    */
    public function set_lead_health_plan($lead_health_plan_id){
        $this->lead_health_plan_id = $lead_health_plan_id;
    }

    /**
    * Checks to make sure we have a $_POST
    * If we have a post we set the post_data_valid to true
    */
    public function check_post(){
        if(!empty($_POST)){
            $this->add_params();
            $this->post_data_valid = true;
        }else{
            return false;
        }
        return true;
    }

    /**
    * Checks and sees if email, phone, first, and last are in the _POST data
    */
    public function is_required_data(){
        if(
            !empty( $_POST['first_name'])
            && !empty( $_POST['last_name'])
            && !empty( $_POST['phone'])
            && !empty( $_POST['email'])
        ) {
            return TRUE;
        }
        return  FALSE;
    }

    /**
    * Takes the _POST parameters, purifies each value and creates hStore Items, also parses phone number
    */
    private function add_params(){

        foreach($_POST as $field => $value) {

            if(in_array($field, $this->allowed_post_parameters)){
                $this->lead_data[$field] = $this->purify($value);
            }
        }

        $this->parse_phone_number();
        $this->setup_hstore_dataset();
    }

    /**
    * Calls the database connection and saves the Lead to T3 Database
    */
    public function save_lead(){

        $this->initialize_database_connection();

        $this->lead_data['lead_type_id']        = 2;
        $this->lead_data['marketing_piece_id']  = $this->marketing_piece_id;

        // Now check and make sure we have values
        if(empty($this->lead_data['lead_type_id'])
            || empty($this->lead_data['first_name'])
            || empty($this->lead_data['last_name'])
            || empty($this->lead_data['area_code'])
            || empty($this->lead_data['prefix'])
            || empty($this->lead_data['line'])
            || empty($this->lead_data['lead_data'])
        ) {
            print_r("saveLead");
            return FALSE;
        }

        $variables = array(
            $this->lead_data['lead_type_id'],
            $this->lead_data['marketing_piece_id'],
            $this->lead_data['first_name'],
            $this->lead_data['last_name'],
            $this->lead_data['area_code'],
            $this->lead_data['prefix'],
            $this->lead_data['line'],
            $this->lead_data['lead_data']
        );

        $result = pg_prepare($this->db_connection, "add_lead", 'INSERT INTO leads (lead_type_id, marketing_piece_id, first_name, last_name, area_code, prefix, line, lead_data
) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)');

        $result = pg_execute($this->db_connection, "add_lead", $variables);

        if($result){
            return TRUE;
        } else {
            return FALSE;
        }

    }

    /**
    * Takes the _POST parameters that need to be added to the hStore and removes it from the parent data set
    */
    private function setup_hstore_dataset(){

        $hStore_data                   = array();

        foreach ($this->hStore_items as $hStore_item) {
            if(!empty($this->lead_data[$hStore_item])){
                $hStore_data[$hStore_item] = $this->lead_data[$hStore_item];
                unset($this->lead_data[$hStore_item]);
            }
        }

        if(!empty($hStore_data)){
            $hStore_data['media_piece_id'] = $this->media_piece_id;
            $this->lead_data['lead_data'] = $this->encode_hstore($hStore_data);
        }
    }

    /**
    * Cleans the input values of a field
    */
    private function purify($value){
        return htmlentities(strip_tags(trim($value)));
    }

    /**
    * Takes a full phone number and parses it for area_code, prefix, line
    */
    private function parse_phone_number(){

        if(!empty($this->lead_data) && !empty($this->lead_data['phone'])){

            $phone = preg_replace("/[^0-9]/", "", $this->lead_data['phone']);
            if(strlen($phone) == 10){
              $phone       = preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "$1-$2-$3", $phone);
              $phone_parts = explode('-', $phone);

              $this->lead_data['area_code'] = $phone_parts[0];
              $this->lead_data['prefix']    = $phone_parts[1];
              $this->lead_data['line']      = $phone_parts[2];
            }
            unset($this->lead_data['phone']);
        }
    }

    /**
    * Function that takes an array and outputs a clean PostgreSQL Hstore-able field
    */
    private function encode_hstore($input, $prepared=false){

        if (is_string($input)){
            if ($input === 'NULL'){
                $output = NULL;
            }else{
                $re = '_("|^)(.*?[^\\\\"])"=>"(.*?[^\\\\"])("|$)_s';
                preg_match_all($re, $input, $pairs);
                $mid = $pairs ? array_combine($pairs[2], $pairs[3]) : array();

                foreach ($mid as $k => $v){
                    $output[trim($k, '"')] = stripslashes($v);
                }
            }

        }elseif (is_null($input)){

            $output = $prepared  ? 'NULL::hstore' : 'NULL';

        }elseif (!is_scalar($input)){

            foreach ((array)$input as $k => $v){

                !is_scalar($v) && ($v = serialize($v));
                $entries[] = '"' . addslashes($k) . '"=>'.'"' . addslashes($v) . '"';

            }

            $mid    = empty($entries) ? '' : join(', ', $entries);
            $output = $prepared ? "'{$mid}'::hstore" : $mid;

        }
        return $output;
    }
}
/***************************************************
***  Main section
****************************************************/

if(empty($_POST)){
    echo 'No Direct Access Allowed';
    return FALSE;
}

//$lead_health_plan_id   = !empty($_POST['lead_health_plan_id']) ? $_POST['lead_health_plan_id'] : NULL;
//$media_piece_id       = !empty($_POST['lead_media_piece_id']) ? $_POST['lead_media_piece_id'] : NULL;
$redirect_url_success = !empty($_POST['lead_success_landing_page']) ? $_POST['lead_success_landing_page'] : NULL;
$redirect_url_error   = !empty($_POST['lead_error_landing_page']) ? $_POST['lead_error_landing_page'] : NULL;

$lead = new Lead; // Setup the Lead Class

$lead->set_media_piece(!empty($_POST['lead_media_piece_id']) ? $_POST['lead_media_piece_id'] : NULL); // Set the media piece ID
$lead->set_marketing_piece(!empty($_POST['marketing_piece_id']) ? $_POST['marketing_piece_id'] : NULL); // Set the marketing piece ID

// Check and see if required data is in the POST if blank return false
if( !$lead->is_required_data() ){
    //print_r("IS Required Error");exit;
    header("Location: ".$redirect_url_error);
}

$lead->check_post(); // Checks to make sure we have a $_POST, this also triggers the class to setup everything for the save

// If we have a valid post
if($lead->post_data_valid){
    // Save the Lead and redirect back to the correct location
    if($lead->save_lead()){
        //print_r("SUCCESS");exit;
        header("Location: ".$redirect_url_success);
    }else{
        //print_r("SAVE ERRORS");exit;
        header("Location: ".$redirect_url_error);
    }
}else{
    //print_r("VALIDATION ERRORS");exit;
    header("Location: ".$redirect_url_error);
}
?>