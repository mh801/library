<?php
    class Cleanstrings{
        /**
        * Cleans the input values of a field
        */
        function purify($value){
            $temp = htmlentities( strip_tags( trim( $value ) ) );
            $bad = array("'",'&quot;',"content-type","bcc:","to:","cc:","href");
            return str_replace($bad,"",$temp);
        }
    }

    /***************************************************
    ***  Main section
    ****************************************************/
    if(empty($_POST)){
        echo 'No Direct Access Allowed';
        return FALSE;
    }

    $clean = new Cleanstrings;
    $site = $clean->purify(!empty( $_POST['site'] ) ? $_POST['site'] : NULL);
    $contest_landing_page = $clean->purify(!empty( $_POST['contest_landing_page'] ) ? $_POST['contest_landing_page'] : NULL);
    $contest_error_landing_page = $clean->purify(!empty( $_POST['contest_error_landing_page'] ) ? $_POST['contest_error_landing_page'] : NULL);
    $contest_success_landing_page = $clean->purify(!empty( $_POST['contest_success_landing_page'] ) ? $_POST['contest_success_landing_page'] : NULL);
    $contest_email_to = $clean->purify(!empty( $_POST['contest_email_to'] ) ? $_POST['contest_email_to'] : NULL);

     if (empty($contest_email_to)) {
        header("Location: ".$contest_error_landing);
     }

    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_subject = "contest entry - ";

    $comments = $clean->purify(!empty( $_POST['comments'] ) ? $_POST['comments'] : NULL);

    $first_name = $clean->purify(!empty( $_POST['first_name'] ) ? $_POST['first_name'] : NULL);

    $last_name =  $clean->purify(!empty( $_POST['last_name'] ) ? $_POST['last_name'] : NULL);

    $phone = $clean->purify(!empty( $_POST['phone'] ) ? $_POST['phone'] : NULL);
    $phone = preg_replace('/[^0-9,]|,[0-9]*$/','',$phone);

    $email = $clean->purify(!empty( $_POST['email'] ) ? $_POST['email'] : NULL);

    // validation expected data exists
    if( !isset($first_name)
        || !isset($first_name)
        || !isset($phone)
        || !isset($comments)) {
        header("Location: ".$contest_error_landing);
    }

    $error = FALSE;
    $name_valid_chars = "/^[A-Za-z .'-]+$/";

    if(!preg_match($name_valid_chars, $first_name)) {
        $error = TRUE;
    }

   if(!preg_match($name_valid_chars, $last_name)) {
        $error = TRUE;
    }

    if( strlen($phone) != 10 ) {
        $error = TRUE;
    }

    $email_valid_chars = "/([\w\-]+\@[\w\-]+\.[\w\-]+)/";
    if (!preg_match($email_valid_chars,$email))
    {
        $error = TRUE;
    }

    if($error) {
        header("Location: ".$contest_error_landing);
    }

    // create email headers
    $headers = 'From: No Reply <no-reply@truhearing.com>'."\r\n".
    'Reply-To: no-reply@truhearing.com'."\r\n" .
    'X-Mailer: PHP/' . phpversion();

//    date_default_timezone_set('UTC');
    date_default_timezone_set('US/Central');

    $email_subject = "Contest Entry - [".$site."]";

    $email_message = "Form details below: \n\n";
    $email_message .= "URL: ".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."\n\n";
    $email_message .= "Date/Time submitted (CDT): ". date("Y-m-d H:i:s")."\n\n";
    $email_message .= "Name: ".$first_name.' '. $last_name."\n\n";
    $email_message .= "Telephone: ".$phone."\n\n";
    $email_message .= "Email: ".$email."\n\n";
    $email_message .= "Comments: ".$comments."\n\n";

    echo (int) mail($contest_email_to, $email_subject, $email_message, $headers);
    header("Location: ".$contest_success_landing_page);

?>